package com.billing.subscription;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@SpringBootApplication
@EnableJpaAuditing
public class SubscriptionBillingApplication {

    public static void main(String[] args) {
        SpringApplication.run(SubscriptionBillingApplication.class, args);
    }
}
