package com.billing.subscription.audit;

import com.billing.subscription.entity.AuditLog;
import com.billing.subscription.repository.AuditLogRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class AuditService {

    private final AuditLogRepository auditLogRepository;

    @Async
    public void log(String entityName, Long entityId, String action, String performedBy, String details) {
        try {
            AuditLog auditLog = AuditLog.builder()
                    .entityName(entityName)
                    .entityId(entityId)
                    .action(action)
                    .performedBy(performedBy != null ? performedBy : "SYSTEM")
                    .details(details)
                    .build();
            auditLogRepository.save(auditLog);
            log.debug("Audit log saved: {} {} {}", entityName, entityId, action);
        } catch (Exception e) {
            log.error("Failed to save audit log: {}", e.getMessage());
        }
    }
}
