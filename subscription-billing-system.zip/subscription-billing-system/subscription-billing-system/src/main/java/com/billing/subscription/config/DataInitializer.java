package com.billing.subscription.config;

import com.billing.subscription.entity.Plan;
import com.billing.subscription.entity.User;
import com.billing.subscription.enums.PlanType;
import com.billing.subscription.enums.UserRole;
import com.billing.subscription.repository.PlanRepository;
import com.billing.subscription.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
@RequiredArgsConstructor
@Slf4j
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PlanRepository planRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        if (userRepository.count() == 0) {
            seedUsers();
        }
        if (planRepository.count() == 0) {
            seedPlans();
        }
    }

    private void seedUsers() {
        log.info("Seeding sample users...");

        userRepository.save(User.builder()
                .firstName("Admin").lastName("User")
                .email("admin@billing.com")
                .password(passwordEncoder.encode("admin123"))
                .phone("9000000001")
                .role(UserRole.ROLE_ADMIN).active(true).build());

        userRepository.save(User.builder()
                .firstName("Manager").lastName("One")
                .email("manager@billing.com")
                .password(passwordEncoder.encode("manager123"))
                .phone("9000000002")
                .role(UserRole.ROLE_MANAGER).active(true).build());

        userRepository.save(User.builder()
                .firstName("John").lastName("Doe")
                .email("john.doe@example.com")
                .password(passwordEncoder.encode("user123"))
                .phone("9000000003")
                .role(UserRole.ROLE_USER).active(true).build());

        userRepository.save(User.builder()
                .firstName("Jane").lastName("Smith")
                .email("jane.smith@example.com")
                .password(passwordEncoder.encode("user123"))
                .phone("9000000004")
                .role(UserRole.ROLE_USER).active(true).build());

        log.info("Seeded 4 users.");
    }

    private void seedPlans() {
        log.info("Seeding sample plans...");

        planRepository.save(Plan.builder()
                .name("Basic Monthly")
                .description("Essential features for individuals")
                .price(new BigDecimal("9.99"))
                .planType(PlanType.MONTHLY)
                .durationInDays(30)
                .maxUsers(1)
                .features("Email Support,5GB Storage,Basic Analytics")
                .active(true).build());

        planRepository.save(Plan.builder()
                .name("Pro Quarterly")
                .description("Advanced features for small teams")
                .price(new BigDecimal("49.99"))
                .planType(PlanType.QUARTERLY)
                .durationInDays(90)
                .maxUsers(5)
                .features("Priority Support,50GB Storage,Advanced Analytics,API Access")
                .active(true).build());

        planRepository.save(Plan.builder()
                .name("Business Annual")
                .description("Full-featured plan for growing businesses")
                .price(new BigDecimal("299.99"))
                .planType(PlanType.ANNUAL)
                .durationInDays(365)
                .maxUsers(25)
                .features("24/7 Support,500GB Storage,Full Analytics,API Access,Custom Integrations,SLA Guarantee")
                .active(true).build());

        planRepository.save(Plan.builder()
                .name("Enterprise Annual")
                .description("Unlimited enterprise-grade subscription")
                .price(new BigDecimal("999.99"))
                .planType(PlanType.ANNUAL)
                .durationInDays(365)
                .maxUsers(null)
                .features("Dedicated Support,Unlimited Storage,Full Analytics,Unlimited API,Custom Integrations,SLA,On-Premise Option")
                .active(true).build());

        log.info("Seeded 4 plans.");
    }
}
