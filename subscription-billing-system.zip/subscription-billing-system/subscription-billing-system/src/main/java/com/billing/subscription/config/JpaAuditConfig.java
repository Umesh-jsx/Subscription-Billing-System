package com.billing.subscription.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.domain.AuditorAware;
import org.springframework.scheduling.annotation.EnableAsync;

import java.util.Optional;

@Configuration
@EnableAsync
public class JpaAuditConfig {

    @Bean
    public AuditorAware<String> auditorProvider() {
        // In production, return logged-in username from SecurityContextHolder
        return () -> Optional.of("SYSTEM");
    }
}
