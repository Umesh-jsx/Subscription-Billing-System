package com.billing.subscription.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI subscriptionBillingOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("Subscription Billing System API")
                        .description("Enterprise Subscription Billing System - REST API Documentation")
                        .version("v1.0.0")
                        .contact(new Contact()
                                .name("Billing Team")
                                .email("billing@example.com"))
                        .license(new License()
                                .name("Apache 2.0")
                                .url("http://springdoc.org")))
                .servers(List.of(
                        new Server().url("http://localhost:8080").description("Development Server")
                ));
    }
}
