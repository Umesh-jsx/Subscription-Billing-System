package com.billing.subscription.controller;

import com.billing.subscription.dto.ApiResponse;
import com.billing.subscription.entity.AuditLog;
import com.billing.subscription.repository.AuditLogRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/audit-logs")
@RequiredArgsConstructor
@Tag(name = "Audit Logs", description = "APIs for viewing audit logs")
public class AuditLogController {

    private final AuditLogRepository auditLogRepository;

    @GetMapping
    @Operation(summary = "Get all audit logs")
    public ResponseEntity<ApiResponse<Page<AuditLog>>> getAllAuditLogs(
            @PageableDefault(size = 20, sort = "timestamp") Pageable pageable) {
        return ResponseEntity.ok(ApiResponse.success(auditLogRepository.findAll(pageable)));
    }

    @GetMapping("/entity/{entityName}")
    @Operation(summary = "Get audit logs by entity name")
    public ResponseEntity<ApiResponse<Page<AuditLog>>> getAuditLogsByEntity(
            @PathVariable String entityName,
            @PageableDefault(size = 20) Pageable pageable) {
        return ResponseEntity.ok(ApiResponse.success(
                auditLogRepository.findByEntityName(entityName, pageable)));
    }

    @GetMapping("/entity/{entityName}/{entityId}")
    @Operation(summary = "Get audit logs by entity name and ID")
    public ResponseEntity<ApiResponse<List<AuditLog>>> getAuditLogsByEntityAndId(
            @PathVariable String entityName,
            @PathVariable Long entityId) {
        return ResponseEntity.ok(ApiResponse.success(
                auditLogRepository.findByEntityNameAndEntityId(entityName, entityId)));
    }
}
