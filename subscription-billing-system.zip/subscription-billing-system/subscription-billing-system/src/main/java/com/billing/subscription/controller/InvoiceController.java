package com.billing.subscription.controller;

import com.billing.subscription.dto.ApiResponse;
import com.billing.subscription.dto.InvoiceDTO;
import com.billing.subscription.enums.BillingStatus;
import com.billing.subscription.service.InvoiceService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/invoices")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Invoice Management", description = "APIs for managing invoices and billing")
public class InvoiceController {

    private final InvoiceService invoiceService;

    @PostMapping
    @Operation(summary = "Create a new invoice")
    public ResponseEntity<ApiResponse<InvoiceDTO.Response>> createInvoice(
            @Valid @RequestBody InvoiceDTO.Request request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success(invoiceService.createInvoice(request), "Invoice created successfully"));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get invoice by ID")
    public ResponseEntity<ApiResponse<InvoiceDTO.Response>> getInvoiceById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(invoiceService.getInvoiceById(id)));
    }

    @GetMapping("/number/{invoiceNumber}")
    @Operation(summary = "Get invoice by invoice number")
    public ResponseEntity<ApiResponse<InvoiceDTO.Response>> getInvoiceByNumber(
            @PathVariable String invoiceNumber) {
        return ResponseEntity.ok(ApiResponse.success(invoiceService.getInvoiceByNumber(invoiceNumber)));
    }

    @GetMapping
    @Operation(summary = "Get all invoices with pagination")
    public ResponseEntity<ApiResponse<Page<InvoiceDTO.Response>>> getAllInvoices(
            @PageableDefault(size = 10, sort = "id") Pageable pageable) {
        return ResponseEntity.ok(ApiResponse.success(invoiceService.getAllInvoices(pageable)));
    }

    @GetMapping("/subscription/{subscriptionId}")
    @Operation(summary = "Get invoices by subscription")
    public ResponseEntity<ApiResponse<Page<InvoiceDTO.Response>>> getInvoicesBySubscription(
            @PathVariable Long subscriptionId,
            @PageableDefault(size = 10) Pageable pageable) {
        return ResponseEntity.ok(ApiResponse.success(
                invoiceService.getInvoicesBySubscription(subscriptionId, pageable)));
    }

    @GetMapping("/status/{status}")
    @Operation(summary = "Get invoices by status")
    public ResponseEntity<ApiResponse<Page<InvoiceDTO.Response>>> getInvoicesByStatus(
            @PathVariable BillingStatus status,
            @PageableDefault(size = 10) Pageable pageable) {
        return ResponseEntity.ok(ApiResponse.success(invoiceService.getInvoicesByStatus(status, pageable)));
    }

    @GetMapping("/search")
    @Operation(summary = "Search invoices")
    public ResponseEntity<ApiResponse<Page<InvoiceDTO.Response>>> searchInvoices(
            @RequestParam(required = false) Long subscriptionId,
            @RequestParam(required = false) BillingStatus status,
            @PageableDefault(size = 10) Pageable pageable) {
        return ResponseEntity.ok(ApiResponse.success(
                invoiceService.searchInvoices(subscriptionId, status, pageable)));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update invoice")
    public ResponseEntity<ApiResponse<InvoiceDTO.Response>> updateInvoice(
            @PathVariable Long id,
            @RequestBody InvoiceDTO.UpdateRequest request) {
        return ResponseEntity.ok(ApiResponse.success(
                invoiceService.updateInvoice(id, request), "Invoice updated successfully"));
    }

    @PatchMapping("/{id}/pay")
    @Operation(summary = "Mark invoice as paid")
    public ResponseEntity<ApiResponse<InvoiceDTO.Response>> markAsPaid(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(invoiceService.markAsPaid(id), "Invoice marked as paid"));
    }

    @PatchMapping("/{id}/overdue")
    @Operation(summary = "Mark invoice as overdue")
    public ResponseEntity<ApiResponse<InvoiceDTO.Response>> markAsOverdue(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(invoiceService.markAsOverdue(id), "Invoice marked as overdue"));
    }

    @PostMapping("/process-overdue")
    @Operation(summary = "Process all overdue invoices")
    public ResponseEntity<ApiResponse<Void>> processOverdueInvoices() {
        invoiceService.processOverdueInvoices();
        return ResponseEntity.ok(ApiResponse.success(null, "Overdue invoices processed"));
    }
}
