package com.billing.subscription.controller;

import com.billing.subscription.dto.ApiResponse;
import com.billing.subscription.dto.PlanDTO;
import com.billing.subscription.enums.PlanType;
import com.billing.subscription.service.PlanService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

@RestController
@RequestMapping("/api/v1/plans")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Plan Management", description = "APIs for managing subscription plans")
public class PlanController {

    private final PlanService planService;

    @PostMapping
    @Operation(summary = "Create a new plan")
    public ResponseEntity<ApiResponse<PlanDTO.Response>> createPlan(
            @Valid @RequestBody PlanDTO.Request request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success(planService.createPlan(request), "Plan created successfully"));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get plan by ID")
    public ResponseEntity<ApiResponse<PlanDTO.Response>> getPlanById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(planService.getPlanById(id)));
    }

    @GetMapping
    @Operation(summary = "Get all plans with pagination")
    public ResponseEntity<ApiResponse<Page<PlanDTO.Response>>> getAllPlans(
            @PageableDefault(size = 10, sort = "id") Pageable pageable) {
        return ResponseEntity.ok(ApiResponse.success(planService.getAllPlans(pageable)));
    }

    @GetMapping("/active")
    @Operation(summary = "Get active plans")
    public ResponseEntity<ApiResponse<Page<PlanDTO.Response>>> getActivePlans(
            @PageableDefault(size = 10) Pageable pageable) {
        return ResponseEntity.ok(ApiResponse.success(planService.getActivePlans(pageable)));
    }

    @GetMapping("/search")
    @Operation(summary = "Search plans")
    public ResponseEntity<ApiResponse<Page<PlanDTO.Response>>> searchPlans(
            @RequestParam(required = false) String search,
            @RequestParam(required = false) Boolean active,
            @PageableDefault(size = 10) Pageable pageable) {
        return ResponseEntity.ok(ApiResponse.success(planService.searchPlans(search, active, pageable)));
    }

    @GetMapping("/type/{planType}")
    @Operation(summary = "Get plans by type")
    public ResponseEntity<ApiResponse<Page<PlanDTO.Response>>> getPlansByType(
            @PathVariable PlanType planType,
            @PageableDefault(size = 10) Pageable pageable) {
        return ResponseEntity.ok(ApiResponse.success(planService.getPlansByType(planType, pageable)));
    }

    @GetMapping("/price-range")
    @Operation(summary = "Get plans by price range")
    public ResponseEntity<ApiResponse<List<PlanDTO.Response>>> getPlansByPriceRange(
            @RequestParam BigDecimal minPrice,
            @RequestParam BigDecimal maxPrice) {
        return ResponseEntity.ok(ApiResponse.success(planService.getPlansByPriceRange(minPrice, maxPrice)));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update plan")
    public ResponseEntity<ApiResponse<PlanDTO.Response>> updatePlan(
            @PathVariable Long id,
            @Valid @RequestBody PlanDTO.Request request) {
        return ResponseEntity.ok(ApiResponse.success(planService.updatePlan(id, request), "Plan updated successfully"));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete plan")
    public ResponseEntity<ApiResponse<Void>> deletePlan(@PathVariable Long id) {
        planService.deletePlan(id);
        return ResponseEntity.ok(ApiResponse.success(null, "Plan deleted successfully"));
    }

    @PatchMapping("/{id}/activate")
    @Operation(summary = "Activate plan")
    public ResponseEntity<ApiResponse<Void>> activatePlan(@PathVariable Long id) {
        planService.activatePlan(id);
        return ResponseEntity.ok(ApiResponse.success(null, "Plan activated"));
    }

    @PatchMapping("/{id}/deactivate")
    @Operation(summary = "Deactivate plan")
    public ResponseEntity<ApiResponse<Void>> deactivatePlan(@PathVariable Long id) {
        planService.deactivatePlan(id);
        return ResponseEntity.ok(ApiResponse.success(null, "Plan deactivated"));
    }
}
