package com.billing.subscription.controller;

import com.billing.subscription.dto.ApiResponse;
import com.billing.subscription.dto.SubscriptionDTO;
import com.billing.subscription.enums.SubscriptionStatus;
import com.billing.subscription.service.SubscriptionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/subscriptions")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Subscription Management", description = "APIs for managing subscriptions")
public class SubscriptionController {

    private final SubscriptionService subscriptionService;

    @PostMapping
    @Operation(summary = "Create a new subscription")
    public ResponseEntity<ApiResponse<SubscriptionDTO.Response>> createSubscription(
            @Valid @RequestBody SubscriptionDTO.Request request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success(subscriptionService.createSubscription(request), "Subscription created"));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get subscription by ID")
    public ResponseEntity<ApiResponse<SubscriptionDTO.Response>> getSubscriptionById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(subscriptionService.getSubscriptionById(id)));
    }

    @GetMapping
    @Operation(summary = "Get all subscriptions with pagination")
    public ResponseEntity<ApiResponse<Page<SubscriptionDTO.Response>>> getAllSubscriptions(
            @PageableDefault(size = 10, sort = "id") Pageable pageable) {
        return ResponseEntity.ok(ApiResponse.success(subscriptionService.getAllSubscriptions(pageable)));
    }

    @GetMapping("/user/{userId}")
    @Operation(summary = "Get subscriptions by user")
    public ResponseEntity<ApiResponse<Page<SubscriptionDTO.Response>>> getSubscriptionsByUser(
            @PathVariable Long userId,
            @PageableDefault(size = 10) Pageable pageable) {
        return ResponseEntity.ok(ApiResponse.success(subscriptionService.getSubscriptionsByUser(userId, pageable)));
    }

    @GetMapping("/plan/{planId}")
    @Operation(summary = "Get subscriptions by plan")
    public ResponseEntity<ApiResponse<Page<SubscriptionDTO.Response>>> getSubscriptionsByPlan(
            @PathVariable Long planId,
            @PageableDefault(size = 10) Pageable pageable) {
        return ResponseEntity.ok(ApiResponse.success(subscriptionService.getSubscriptionsByPlan(planId, pageable)));
    }

    @GetMapping("/status/{status}")
    @Operation(summary = "Get subscriptions by status")
    public ResponseEntity<ApiResponse<Page<SubscriptionDTO.Response>>> getSubscriptionsByStatus(
            @PathVariable SubscriptionStatus status,
            @PageableDefault(size = 10) Pageable pageable) {
        return ResponseEntity.ok(ApiResponse.success(subscriptionService.getSubscriptionsByStatus(status, pageable)));
    }

    @GetMapping("/search")
    @Operation(summary = "Search subscriptions")
    public ResponseEntity<ApiResponse<Page<SubscriptionDTO.Response>>> searchSubscriptions(
            @RequestParam(required = false) Long userId,
            @RequestParam(required = false) Long planId,
            @RequestParam(required = false) SubscriptionStatus status,
            @PageableDefault(size = 10) Pageable pageable) {
        return ResponseEntity.ok(ApiResponse.success(
                subscriptionService.searchSubscriptions(userId, planId, status, pageable)));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update subscription")
    public ResponseEntity<ApiResponse<SubscriptionDTO.Response>> updateSubscription(
            @PathVariable Long id,
            @RequestBody SubscriptionDTO.UpdateRequest request) {
        return ResponseEntity.ok(ApiResponse.success(
                subscriptionService.updateSubscription(id, request), "Subscription updated"));
    }

    @PatchMapping("/{id}/cancel")
    @Operation(summary = "Cancel subscription")
    public ResponseEntity<ApiResponse<Void>> cancelSubscription(@PathVariable Long id) {
        subscriptionService.cancelSubscription(id);
        return ResponseEntity.ok(ApiResponse.success(null, "Subscription cancelled"));
    }

    @PatchMapping("/{id}/activate")
    @Operation(summary = "Activate subscription")
    public ResponseEntity<ApiResponse<Void>> activateSubscription(@PathVariable Long id) {
        subscriptionService.activateSubscription(id);
        return ResponseEntity.ok(ApiResponse.success(null, "Subscription activated"));
    }

    @PatchMapping("/{id}/renew")
    @Operation(summary = "Renew subscription")
    public ResponseEntity<ApiResponse<Void>> renewSubscription(@PathVariable Long id) {
        subscriptionService.renewSubscription(id);
        return ResponseEntity.ok(ApiResponse.success(null, "Subscription renewed"));
    }
}
