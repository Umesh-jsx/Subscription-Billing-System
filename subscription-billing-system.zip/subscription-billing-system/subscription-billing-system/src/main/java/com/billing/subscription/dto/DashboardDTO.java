package com.billing.subscription.dto;

import lombok.*;

import java.math.BigDecimal;
import java.util.Map;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DashboardDTO {
    private Long totalUsers;
    private Long activeUsers;
    private Long totalPlans;
    private Long activePlans;
    private Long totalSubscriptions;
    private Long activeSubscriptions;
    private Long pendingSubscriptions;
    private Long cancelledSubscriptions;
    private Long totalInvoices;
    private Long paidInvoices;
    private Long pendingInvoices;
    private Long overdueInvoices;
    private BigDecimal totalRevenue;
    private BigDecimal pendingRevenue;
    private Map<String, Long> subscriptionsByPlan;
    private Map<String, BigDecimal> revenueByPlan;
}
