package com.billing.subscription.dto;

import com.billing.subscription.enums.BillingStatus;
import jakarta.validation.constraints.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class InvoiceDTO {

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class Request {
        @NotNull(message = "Subscription ID is required")
        private Long subscriptionId;

        @NotNull(message = "Amount is required")
        @DecimalMin(value = "0.0", inclusive = false)
        private BigDecimal amount;

        @DecimalMin(value = "0.0")
        private BigDecimal taxAmount;

        @NotNull(message = "Due date is required")
        private LocalDate dueDate;

        @Size(max = 500)
        private String notes;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class UpdateRequest {
        private BillingStatus status;
        private LocalDate paidDate;
        private String notes;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class Response {
        private Long id;
        private String invoiceNumber;
        private Long subscriptionId;
        private String userFullName;
        private String planName;
        private BigDecimal amount;
        private BigDecimal taxAmount;
        private BigDecimal totalAmount;
        private BillingStatus status;
        private LocalDate dueDate;
        private LocalDate paidDate;
        private String notes;
        private LocalDateTime createdAt;
        private LocalDateTime updatedAt;
    }
}
