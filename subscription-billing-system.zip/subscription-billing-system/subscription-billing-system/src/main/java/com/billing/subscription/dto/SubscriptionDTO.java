package com.billing.subscription.dto;

import com.billing.subscription.enums.SubscriptionStatus;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class SubscriptionDTO {

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class Request {
        @NotNull(message = "User ID is required")
        private Long userId;

        @NotNull(message = "Plan ID is required")
        private Long planId;

        @NotNull(message = "Start date is required")
        private LocalDate startDate;

        private Boolean autoRenew;
        private String notes;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class UpdateRequest {
        private SubscriptionStatus status;
        private Boolean autoRenew;
        private String notes;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class Response {
        private Long id;
        private Long userId;
        private String userFullName;
        private String userEmail;
        private Long planId;
        private String planName;
        private SubscriptionStatus status;
        private LocalDate startDate;
        private LocalDate endDate;
        private Boolean autoRenew;
        private String notes;
        private LocalDateTime createdAt;
        private LocalDateTime updatedAt;
    }
}
