package com.billing.subscription.enums;

public enum BillingStatus {
    PENDING,
    PAID,
    FAILED,
    REFUNDED,
    OVERDUE
}
