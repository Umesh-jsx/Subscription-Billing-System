package com.billing.subscription.enums;

public enum PlanType {
    MONTHLY,
    QUARTERLY,
    SEMI_ANNUAL,
    ANNUAL
}
