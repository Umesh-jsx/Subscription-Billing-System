package com.billing.subscription.enums;

public enum SubscriptionStatus {
    ACTIVE,
    INACTIVE,
    CANCELLED,
    EXPIRED,
    PENDING,
    SUSPENDED
}
