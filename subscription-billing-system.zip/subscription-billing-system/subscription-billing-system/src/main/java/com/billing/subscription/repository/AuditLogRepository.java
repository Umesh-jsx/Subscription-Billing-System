package com.billing.subscription.repository;

import com.billing.subscription.entity.AuditLog;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {

    Page<AuditLog> findByEntityName(String entityName, Pageable pageable);

    List<AuditLog> findByEntityNameAndEntityId(String entityName, Long entityId);

    Page<AuditLog> findByPerformedBy(String performedBy, Pageable pageable);

    List<AuditLog> findByTimestampBetween(LocalDateTime from, LocalDateTime to);
}
