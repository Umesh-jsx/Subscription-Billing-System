package com.billing.subscription.repository;

import com.billing.subscription.entity.Invoice;
import com.billing.subscription.enums.BillingStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface InvoiceRepository extends JpaRepository<Invoice, Long> {

    Optional<Invoice> findByInvoiceNumber(String invoiceNumber);

    boolean existsByInvoiceNumber(String invoiceNumber);

    Page<Invoice> findBySubscriptionId(Long subscriptionId, Pageable pageable);

    Page<Invoice> findByStatus(BillingStatus status, Pageable pageable);

    @Query("SELECT i FROM Invoice i WHERE i.status = 'PENDING' AND i.dueDate < :today")
    List<Invoice> findOverdueInvoices(@Param("today") LocalDate today);

    @Query("SELECT i FROM Invoice i WHERE " +
           "(:subscriptionId IS NULL OR i.subscription.id = :subscriptionId) " +
           "AND (:status IS NULL OR i.status = :status)")
    Page<Invoice> searchInvoices(@Param("subscriptionId") Long subscriptionId,
                                 @Param("status") BillingStatus status,
                                 Pageable pageable);

    @Query("SELECT COALESCE(SUM(i.totalAmount), 0) FROM Invoice i WHERE i.status = 'PAID'")
    BigDecimal calculateTotalRevenue();

    @Query("SELECT COALESCE(SUM(i.totalAmount), 0) FROM Invoice i WHERE i.status = 'PENDING'")
    BigDecimal calculatePendingRevenue();

    @Query("SELECT i.subscription.plan.name, COALESCE(SUM(i.totalAmount), 0) FROM Invoice i WHERE i.status = 'PAID' GROUP BY i.subscription.plan.name")
    List<Object[]> calculateRevenueByPlan();

    long countByStatus(BillingStatus status);
}
