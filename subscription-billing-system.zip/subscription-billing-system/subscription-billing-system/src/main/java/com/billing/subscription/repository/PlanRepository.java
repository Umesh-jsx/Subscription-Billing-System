package com.billing.subscription.repository;

import com.billing.subscription.entity.Plan;
import com.billing.subscription.enums.PlanType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Repository
public interface PlanRepository extends JpaRepository<Plan, Long> {

    boolean existsByName(String name);

    Page<Plan> findByActiveTrue(Pageable pageable);

    List<Plan> findByActiveTrueOrderByPriceAsc();

    Page<Plan> findByPlanType(PlanType planType, Pageable pageable);

    @Query("SELECT p FROM Plan p WHERE " +
           "(:search IS NULL OR LOWER(p.name) LIKE LOWER(CONCAT('%', :search, '%'))) " +
           "AND (:active IS NULL OR p.active = :active)")
    Page<Plan> searchPlans(@Param("search") String search,
                           @Param("active") Boolean active,
                           Pageable pageable);

    @Query("SELECT p FROM Plan p WHERE p.price BETWEEN :minPrice AND :maxPrice AND p.active = true")
    List<Plan> findByPriceRange(@Param("minPrice") BigDecimal minPrice,
                                @Param("maxPrice") BigDecimal maxPrice);

    long countByActiveTrue();
}
