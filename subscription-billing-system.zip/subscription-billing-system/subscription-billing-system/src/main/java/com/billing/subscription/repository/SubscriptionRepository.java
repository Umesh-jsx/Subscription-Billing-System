package com.billing.subscription.repository;

import com.billing.subscription.entity.Subscription;
import com.billing.subscription.enums.SubscriptionStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface SubscriptionRepository extends JpaRepository<Subscription, Long> {

    Page<Subscription> findByUserId(Long userId, Pageable pageable);

    Page<Subscription> findByPlanId(Long planId, Pageable pageable);

    Page<Subscription> findByStatus(SubscriptionStatus status, Pageable pageable);

    List<Subscription> findByUserIdAndStatus(Long userId, SubscriptionStatus status);

    @Query("SELECT s FROM Subscription s WHERE s.endDate <= :date AND s.status = 'ACTIVE'")
    List<Subscription> findExpiringSubscriptions(@Param("date") LocalDate date);

    @Query("SELECT s FROM Subscription s WHERE s.autoRenew = true AND s.endDate = :date AND s.status = 'ACTIVE'")
    List<Subscription> findSubscriptionsForRenewal(@Param("date") LocalDate date);

    @Query("SELECT s FROM Subscription s WHERE " +
           "(:userId IS NULL OR s.user.id = :userId) " +
           "AND (:planId IS NULL OR s.plan.id = :planId) " +
           "AND (:status IS NULL OR s.status = :status)")
    Page<Subscription> searchSubscriptions(@Param("userId") Long userId,
                                           @Param("planId") Long planId,
                                           @Param("status") SubscriptionStatus status,
                                           Pageable pageable);

    long countByStatus(SubscriptionStatus status);

    @Query("SELECT s.plan.name, COUNT(s) FROM Subscription s WHERE s.status = 'ACTIVE' GROUP BY s.plan.name")
    List<Object[]> countActiveSubscriptionsByPlan();
}
