package com.billing.subscription.service;

import com.billing.subscription.dto.DashboardDTO;

public interface DashboardService {
    DashboardDTO getDashboardStats();
}
