package com.billing.subscription.service;

import com.billing.subscription.dto.InvoiceDTO;
import com.billing.subscription.enums.BillingStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface InvoiceService {

    InvoiceDTO.Response createInvoice(InvoiceDTO.Request request);

    InvoiceDTO.Response getInvoiceById(Long id);

    InvoiceDTO.Response getInvoiceByNumber(String invoiceNumber);

    Page<InvoiceDTO.Response> getAllInvoices(Pageable pageable);

    Page<InvoiceDTO.Response> getInvoicesBySubscription(Long subscriptionId, Pageable pageable);

    Page<InvoiceDTO.Response> getInvoicesByStatus(BillingStatus status, Pageable pageable);

    Page<InvoiceDTO.Response> searchInvoices(Long subscriptionId, BillingStatus status, Pageable pageable);

    InvoiceDTO.Response updateInvoice(Long id, InvoiceDTO.UpdateRequest request);

    InvoiceDTO.Response markAsPaid(Long id);

    InvoiceDTO.Response markAsOverdue(Long id);

    void processOverdueInvoices();
}
