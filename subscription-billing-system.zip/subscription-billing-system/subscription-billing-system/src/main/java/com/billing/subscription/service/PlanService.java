package com.billing.subscription.service;

import com.billing.subscription.dto.PlanDTO;
import com.billing.subscription.enums.PlanType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.math.BigDecimal;
import java.util.List;

public interface PlanService {

    PlanDTO.Response createPlan(PlanDTO.Request request);

    PlanDTO.Response getPlanById(Long id);

    Page<PlanDTO.Response> getAllPlans(Pageable pageable);

    Page<PlanDTO.Response> getActivePlans(Pageable pageable);

    Page<PlanDTO.Response> searchPlans(String search, Boolean active, Pageable pageable);

    Page<PlanDTO.Response> getPlansByType(PlanType planType, Pageable pageable);

    List<PlanDTO.Response> getPlansByPriceRange(BigDecimal minPrice, BigDecimal maxPrice);

    PlanDTO.Response updatePlan(Long id, PlanDTO.Request request);

    void deletePlan(Long id);

    void activatePlan(Long id);

    void deactivatePlan(Long id);
}
