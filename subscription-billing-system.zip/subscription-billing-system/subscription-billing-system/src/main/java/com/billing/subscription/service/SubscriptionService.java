package com.billing.subscription.service;

import com.billing.subscription.dto.SubscriptionDTO;
import com.billing.subscription.enums.SubscriptionStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface SubscriptionService {

    SubscriptionDTO.Response createSubscription(SubscriptionDTO.Request request);

    SubscriptionDTO.Response getSubscriptionById(Long id);

    Page<SubscriptionDTO.Response> getAllSubscriptions(Pageable pageable);

    Page<SubscriptionDTO.Response> getSubscriptionsByUser(Long userId, Pageable pageable);

    Page<SubscriptionDTO.Response> getSubscriptionsByPlan(Long planId, Pageable pageable);

    Page<SubscriptionDTO.Response> getSubscriptionsByStatus(SubscriptionStatus status, Pageable pageable);

    Page<SubscriptionDTO.Response> searchSubscriptions(Long userId, Long planId,
                                                        SubscriptionStatus status, Pageable pageable);

    SubscriptionDTO.Response updateSubscription(Long id, SubscriptionDTO.UpdateRequest request);

    void cancelSubscription(Long id);

    void activateSubscription(Long id);

    void renewSubscription(Long id);
}
