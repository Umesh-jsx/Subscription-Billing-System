package com.billing.subscription.service;

import com.billing.subscription.dto.UserDTO;
import com.billing.subscription.enums.UserRole;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface UserService {

    UserDTO.Response createUser(UserDTO.Request request);

    UserDTO.Response getUserById(Long id);

    UserDTO.Response getUserByEmail(String email);

    Page<UserDTO.Response> getAllUsers(Pageable pageable);

    Page<UserDTO.Response> searchUsers(String search, Pageable pageable);

    Page<UserDTO.Response> getUsersByRole(UserRole role, Pageable pageable);

    UserDTO.Response updateUser(Long id, UserDTO.UpdateRequest request);

    void deleteUser(Long id);

    void activateUser(Long id);

    void deactivateUser(Long id);
}
