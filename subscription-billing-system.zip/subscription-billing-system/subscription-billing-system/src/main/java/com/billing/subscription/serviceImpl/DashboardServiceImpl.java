package com.billing.subscription.serviceImpl;

import com.billing.subscription.dto.DashboardDTO;
import com.billing.subscription.enums.BillingStatus;
import com.billing.subscription.enums.SubscriptionStatus;
import com.billing.subscription.repository.InvoiceRepository;
import com.billing.subscription.repository.PlanRepository;
import com.billing.subscription.repository.SubscriptionRepository;
import com.billing.subscription.repository.UserRepository;
import com.billing.subscription.service.DashboardService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional(readOnly = true)
public class DashboardServiceImpl implements DashboardService {

    private final UserRepository userRepository;
    private final PlanRepository planRepository;
    private final SubscriptionRepository subscriptionRepository;
    private final InvoiceRepository invoiceRepository;

    @Override
    public DashboardDTO getDashboardStats() {
        log.info("Fetching dashboard statistics");

        // Subscription by plan map
        List<Object[]> subsByPlan = subscriptionRepository.countActiveSubscriptionsByPlan();
        Map<String, Long> subscriptionsByPlan = new HashMap<>();
        for (Object[] row : subsByPlan) {
            subscriptionsByPlan.put((String) row[0], (Long) row[1]);
        }

        // Revenue by plan map
        List<Object[]> revByPlan = invoiceRepository.calculateRevenueByPlan();
        Map<String, BigDecimal> revenueByPlan = new HashMap<>();
        for (Object[] row : revByPlan) {
            revenueByPlan.put((String) row[0], (BigDecimal) row[1]);
        }

        return DashboardDTO.builder()
                .totalUsers(userRepository.count())
                .activeUsers(userRepository.countByActiveTrue())
                .totalPlans(planRepository.count())
                .activePlans(planRepository.countByActiveTrue())
                .totalSubscriptions(subscriptionRepository.count())
                .activeSubscriptions(subscriptionRepository.countByStatus(SubscriptionStatus.ACTIVE))
                .pendingSubscriptions(subscriptionRepository.countByStatus(SubscriptionStatus.PENDING))
                .cancelledSubscriptions(subscriptionRepository.countByStatus(SubscriptionStatus.CANCELLED))
                .totalInvoices(invoiceRepository.count())
                .paidInvoices(invoiceRepository.countByStatus(BillingStatus.PAID))
                .pendingInvoices(invoiceRepository.countByStatus(BillingStatus.PENDING))
                .overdueInvoices(invoiceRepository.countByStatus(BillingStatus.OVERDUE))
                .totalRevenue(invoiceRepository.calculateTotalRevenue())
                .pendingRevenue(invoiceRepository.calculatePendingRevenue())
                .subscriptionsByPlan(subscriptionsByPlan)
                .revenueByPlan(revenueByPlan)
                .build();
    }
}
