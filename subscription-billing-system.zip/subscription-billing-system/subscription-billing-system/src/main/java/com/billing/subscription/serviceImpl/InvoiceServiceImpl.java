package com.billing.subscription.serviceImpl;

import com.billing.subscription.audit.AuditService;
import com.billing.subscription.dto.InvoiceDTO;
import com.billing.subscription.entity.Invoice;
import com.billing.subscription.entity.Subscription;
import com.billing.subscription.enums.BillingStatus;
import com.billing.subscription.exception.ResourceNotFoundException;
import com.billing.subscription.repository.InvoiceRepository;
import com.billing.subscription.repository.SubscriptionRepository;
import com.billing.subscription.service.InvoiceService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class InvoiceServiceImpl implements InvoiceService {

    private final InvoiceRepository invoiceRepository;
    private final SubscriptionRepository subscriptionRepository;
    private final AuditService auditService;

    @Override
    public InvoiceDTO.Response createInvoice(InvoiceDTO.Request request) {
        Subscription subscription = subscriptionRepository.findById(request.getSubscriptionId())
                .orElseThrow(() -> new ResourceNotFoundException("Subscription", "id", request.getSubscriptionId()));

        BigDecimal tax = request.getTaxAmount() != null ? request.getTaxAmount() : BigDecimal.ZERO;
        BigDecimal total = request.getAmount().add(tax);

        Invoice invoice = Invoice.builder()
                .invoiceNumber(generateInvoiceNumber())
                .subscription(subscription)
                .amount(request.getAmount())
                .taxAmount(tax)
                .totalAmount(total)
                .status(BillingStatus.PENDING)
                .dueDate(request.getDueDate())
                .notes(request.getNotes())
                .build();
        Invoice saved = invoiceRepository.save(invoice);
        auditService.log("Invoice", saved.getId(), "CREATE", "SYSTEM",
                "Invoice created: " + saved.getInvoiceNumber());
        return toResponse(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public InvoiceDTO.Response getInvoiceById(Long id) {
        return toResponse(findInvoiceById(id));
    }

    @Override
    @Transactional(readOnly = true)
    public InvoiceDTO.Response getInvoiceByNumber(String invoiceNumber) {
        Invoice invoice = invoiceRepository.findByInvoiceNumber(invoiceNumber)
                .orElseThrow(() -> new ResourceNotFoundException("Invoice", "invoiceNumber", invoiceNumber));
        return toResponse(invoice);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<InvoiceDTO.Response> getAllInvoices(Pageable pageable) {
        return invoiceRepository.findAll(pageable).map(this::toResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<InvoiceDTO.Response> getInvoicesBySubscription(Long subscriptionId, Pageable pageable) {
        return invoiceRepository.findBySubscriptionId(subscriptionId, pageable).map(this::toResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<InvoiceDTO.Response> getInvoicesByStatus(BillingStatus status, Pageable pageable) {
        return invoiceRepository.findByStatus(status, pageable).map(this::toResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<InvoiceDTO.Response> searchInvoices(Long subscriptionId, BillingStatus status, Pageable pageable) {
        return invoiceRepository.searchInvoices(subscriptionId, status, pageable).map(this::toResponse);
    }

    @Override
    public InvoiceDTO.Response updateInvoice(Long id, InvoiceDTO.UpdateRequest request) {
        Invoice invoice = findInvoiceById(id);
        if (request.getStatus() != null) invoice.setStatus(request.getStatus());
        if (request.getPaidDate() != null) invoice.setPaidDate(request.getPaidDate());
        if (request.getNotes() != null) invoice.setNotes(request.getNotes());
        Invoice updated = invoiceRepository.save(invoice);
        auditService.log("Invoice", id, "UPDATE", "SYSTEM", "Invoice updated: " + updated.getInvoiceNumber());
        return toResponse(updated);
    }

    @Override
    public InvoiceDTO.Response markAsPaid(Long id) {
        Invoice invoice = findInvoiceById(id);
        invoice.setStatus(BillingStatus.PAID);
        invoice.setPaidDate(LocalDate.now());
        Invoice updated = invoiceRepository.save(invoice);
        auditService.log("Invoice", id, "PAID", "SYSTEM", "Invoice marked as paid");
        return toResponse(updated);
    }

    @Override
    public InvoiceDTO.Response markAsOverdue(Long id) {
        Invoice invoice = findInvoiceById(id);
        invoice.setStatus(BillingStatus.OVERDUE);
        Invoice updated = invoiceRepository.save(invoice);
        auditService.log("Invoice", id, "OVERDUE", "SYSTEM", "Invoice marked as overdue");
        return toResponse(updated);
    }

    @Override
    public void processOverdueInvoices() {
        List<Invoice> overdue = invoiceRepository.findOverdueInvoices(LocalDate.now());
        overdue.forEach(inv -> {
            inv.setStatus(BillingStatus.OVERDUE);
            invoiceRepository.save(inv);
            auditService.log("Invoice", inv.getId(), "AUTO_OVERDUE", "SYSTEM", "Auto-marked overdue");
        });
        log.info("Processed {} overdue invoices", overdue.size());
    }

    private Invoice findInvoiceById(Long id) {
        return invoiceRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Invoice", "id", id));
    }

    private String generateInvoiceNumber() {
        String date = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        String unique = UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        return "INV-" + date + "-" + unique;
    }

    private InvoiceDTO.Response toResponse(Invoice invoice) {
        Subscription sub = invoice.getSubscription();
        return InvoiceDTO.Response.builder()
                .id(invoice.getId())
                .invoiceNumber(invoice.getInvoiceNumber())
                .subscriptionId(sub.getId())
                .userFullName(sub.getUser().getFirstName() + " " + sub.getUser().getLastName())
                .planName(sub.getPlan().getName())
                .amount(invoice.getAmount())
                .taxAmount(invoice.getTaxAmount())
                .totalAmount(invoice.getTotalAmount())
                .status(invoice.getStatus())
                .dueDate(invoice.getDueDate())
                .paidDate(invoice.getPaidDate())
                .notes(invoice.getNotes())
                .createdAt(invoice.getCreatedAt())
                .updatedAt(invoice.getUpdatedAt())
                .build();
    }
}
