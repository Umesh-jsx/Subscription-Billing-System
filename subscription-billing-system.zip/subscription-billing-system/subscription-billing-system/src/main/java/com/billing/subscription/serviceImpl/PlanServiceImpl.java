package com.billing.subscription.serviceImpl;

import com.billing.subscription.audit.AuditService;
import com.billing.subscription.dto.PlanDTO;
import com.billing.subscription.entity.Plan;
import com.billing.subscription.enums.PlanType;
import com.billing.subscription.exception.DuplicateResourceException;
import com.billing.subscription.exception.ResourceNotFoundException;
import com.billing.subscription.repository.PlanRepository;
import com.billing.subscription.service.PlanService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class PlanServiceImpl implements PlanService {

    private final PlanRepository planRepository;
    private final AuditService auditService;

    @Override
    public PlanDTO.Response createPlan(PlanDTO.Request request) {
        log.info("Creating plan: {}", request.getName());
        if (planRepository.existsByName(request.getName())) {
            throw new DuplicateResourceException("Plan already exists with name: " + request.getName());
        }
        Plan plan = Plan.builder()
                .name(request.getName())
                .description(request.getDescription())
                .price(request.getPrice())
                .planType(request.getPlanType())
                .durationInDays(request.getDurationInDays())
                .maxUsers(request.getMaxUsers())
                .features(request.getFeatures())
                .active(request.getActive() != null ? request.getActive() : true)
                .build();
        Plan saved = planRepository.save(plan);
        auditService.log("Plan", saved.getId(), "CREATE", "SYSTEM", "Plan created: " + saved.getName());
        return toResponse(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public PlanDTO.Response getPlanById(Long id) {
        return toResponse(findPlanById(id));
    }

    @Override
    @Transactional(readOnly = true)
    public Page<PlanDTO.Response> getAllPlans(Pageable pageable) {
        return planRepository.findAll(pageable).map(this::toResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<PlanDTO.Response> getActivePlans(Pageable pageable) {
        return planRepository.findByActiveTrue(pageable).map(this::toResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<PlanDTO.Response> searchPlans(String search, Boolean active, Pageable pageable) {
        return planRepository.searchPlans(search, active, pageable).map(this::toResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<PlanDTO.Response> getPlansByType(PlanType planType, Pageable pageable) {
        return planRepository.findByPlanType(planType, pageable).map(this::toResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public List<PlanDTO.Response> getPlansByPriceRange(BigDecimal minPrice, BigDecimal maxPrice) {
        return planRepository.findByPriceRange(minPrice, maxPrice)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Override
    public PlanDTO.Response updatePlan(Long id, PlanDTO.Request request) {
        log.info("Updating plan with id: {}", id);
        Plan plan = findPlanById(id);
        if (!plan.getName().equals(request.getName()) && planRepository.existsByName(request.getName())) {
            throw new DuplicateResourceException("Plan already exists with name: " + request.getName());
        }
        plan.setName(request.getName());
        plan.setDescription(request.getDescription());
        plan.setPrice(request.getPrice());
        plan.setPlanType(request.getPlanType());
        plan.setDurationInDays(request.getDurationInDays());
        plan.setMaxUsers(request.getMaxUsers());
        plan.setFeatures(request.getFeatures());
        if (request.getActive() != null) plan.setActive(request.getActive());
        Plan updated = planRepository.save(plan);
        auditService.log("Plan", id, "UPDATE", "SYSTEM", "Plan updated: " + updated.getName());
        return toResponse(updated);
    }

    @Override
    public void deletePlan(Long id) {
        Plan plan = findPlanById(id);
        planRepository.delete(plan);
        auditService.log("Plan", id, "DELETE", "SYSTEM", "Plan deleted: " + plan.getName());
    }

    @Override
    public void activatePlan(Long id) {
        Plan plan = findPlanById(id);
        plan.setActive(true);
        planRepository.save(plan);
        auditService.log("Plan", id, "ACTIVATE", "SYSTEM", "Plan activated");
    }

    @Override
    public void deactivatePlan(Long id) {
        Plan plan = findPlanById(id);
        plan.setActive(false);
        planRepository.save(plan);
        auditService.log("Plan", id, "DEACTIVATE", "SYSTEM", "Plan deactivated");
    }

    private Plan findPlanById(Long id) {
        return planRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Plan", "id", id));
    }

    private PlanDTO.Response toResponse(Plan plan) {
        return PlanDTO.Response.builder()
                .id(plan.getId())
                .name(plan.getName())
                .description(plan.getDescription())
                .price(plan.getPrice())
                .planType(plan.getPlanType())
                .durationInDays(plan.getDurationInDays())
                .maxUsers(plan.getMaxUsers())
                .features(plan.getFeatures())
                .active(plan.getActive())
                .createdAt(plan.getCreatedAt())
                .updatedAt(plan.getUpdatedAt())
                .build();
    }
}
