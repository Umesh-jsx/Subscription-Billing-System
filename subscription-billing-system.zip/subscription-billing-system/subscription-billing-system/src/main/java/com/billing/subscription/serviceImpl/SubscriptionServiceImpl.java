package com.billing.subscription.serviceImpl;

import com.billing.subscription.audit.AuditService;
import com.billing.subscription.dto.SubscriptionDTO;
import com.billing.subscription.entity.Plan;
import com.billing.subscription.entity.Subscription;
import com.billing.subscription.entity.User;
import com.billing.subscription.enums.SubscriptionStatus;
import com.billing.subscription.exception.BusinessException;
import com.billing.subscription.exception.ResourceNotFoundException;
import com.billing.subscription.repository.PlanRepository;
import com.billing.subscription.repository.SubscriptionRepository;
import com.billing.subscription.repository.UserRepository;
import com.billing.subscription.service.SubscriptionService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class SubscriptionServiceImpl implements SubscriptionService {

    private final SubscriptionRepository subscriptionRepository;
    private final UserRepository userRepository;
    private final PlanRepository planRepository;
    private final AuditService auditService;

    @Override
    public SubscriptionDTO.Response createSubscription(SubscriptionDTO.Request request) {
        log.info("Creating subscription for user: {} with plan: {}", request.getUserId(), request.getPlanId());
        User user = userRepository.findById(request.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", request.getUserId()));
        Plan plan = planRepository.findById(request.getPlanId())
                .orElseThrow(() -> new ResourceNotFoundException("Plan", "id", request.getPlanId()));
        if (!plan.getActive()) {
            throw new BusinessException("Cannot subscribe to an inactive plan");
        }
        LocalDate startDate = request.getStartDate();
        LocalDate endDate = startDate.plusDays(plan.getDurationInDays());

        Subscription subscription = Subscription.builder()
                .user(user)
                .plan(plan)
                .status(SubscriptionStatus.ACTIVE)
                .startDate(startDate)
                .endDate(endDate)
                .autoRenew(request.getAutoRenew() != null ? request.getAutoRenew() : false)
                .notes(request.getNotes())
                .build();
        Subscription saved = subscriptionRepository.save(subscription);
        auditService.log("Subscription", saved.getId(), "CREATE", "SYSTEM",
                "Subscription created for user: " + user.getEmail());
        return toResponse(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public SubscriptionDTO.Response getSubscriptionById(Long id) {
        return toResponse(findSubscriptionById(id));
    }

    @Override
    @Transactional(readOnly = true)
    public Page<SubscriptionDTO.Response> getAllSubscriptions(Pageable pageable) {
        return subscriptionRepository.findAll(pageable).map(this::toResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<SubscriptionDTO.Response> getSubscriptionsByUser(Long userId, Pageable pageable) {
        return subscriptionRepository.findByUserId(userId, pageable).map(this::toResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<SubscriptionDTO.Response> getSubscriptionsByPlan(Long planId, Pageable pageable) {
        return subscriptionRepository.findByPlanId(planId, pageable).map(this::toResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<SubscriptionDTO.Response> getSubscriptionsByStatus(SubscriptionStatus status, Pageable pageable) {
        return subscriptionRepository.findByStatus(status, pageable).map(this::toResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<SubscriptionDTO.Response> searchSubscriptions(Long userId, Long planId,
                                                               SubscriptionStatus status, Pageable pageable) {
        return subscriptionRepository.searchSubscriptions(userId, planId, status, pageable).map(this::toResponse);
    }

    @Override
    public SubscriptionDTO.Response updateSubscription(Long id, SubscriptionDTO.UpdateRequest request) {
        Subscription subscription = findSubscriptionById(id);
        if (request.getStatus() != null) subscription.setStatus(request.getStatus());
        if (request.getAutoRenew() != null) subscription.setAutoRenew(request.getAutoRenew());
        if (request.getNotes() != null) subscription.setNotes(request.getNotes());
        Subscription updated = subscriptionRepository.save(subscription);
        auditService.log("Subscription", id, "UPDATE", "SYSTEM", "Subscription updated");
        return toResponse(updated);
    }

    @Override
    public void cancelSubscription(Long id) {
        Subscription subscription = findSubscriptionById(id);
        if (subscription.getStatus() == SubscriptionStatus.CANCELLED) {
            throw new BusinessException("Subscription is already cancelled");
        }
        subscription.setStatus(SubscriptionStatus.CANCELLED);
        subscriptionRepository.save(subscription);
        auditService.log("Subscription", id, "CANCEL", "SYSTEM", "Subscription cancelled");
    }

    @Override
    public void activateSubscription(Long id) {
        Subscription subscription = findSubscriptionById(id);
        subscription.setStatus(SubscriptionStatus.ACTIVE);
        subscriptionRepository.save(subscription);
        auditService.log("Subscription", id, "ACTIVATE", "SYSTEM", "Subscription activated");
    }

    @Override
    public void renewSubscription(Long id) {
        Subscription subscription = findSubscriptionById(id);
        Plan plan = subscription.getPlan();
        LocalDate newEnd = subscription.getEndDate().plusDays(plan.getDurationInDays());
        subscription.setEndDate(newEnd);
        subscription.setStatus(SubscriptionStatus.ACTIVE);
        subscriptionRepository.save(subscription);
        auditService.log("Subscription", id, "RENEW", "SYSTEM", "Subscription renewed until " + newEnd);
    }

    private Subscription findSubscriptionById(Long id) {
        return subscriptionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Subscription", "id", id));
    }

    private SubscriptionDTO.Response toResponse(Subscription s) {
        return SubscriptionDTO.Response.builder()
                .id(s.getId())
                .userId(s.getUser().getId())
                .userFullName(s.getUser().getFirstName() + " " + s.getUser().getLastName())
                .userEmail(s.getUser().getEmail())
                .planId(s.getPlan().getId())
                .planName(s.getPlan().getName())
                .status(s.getStatus())
                .startDate(s.getStartDate())
                .endDate(s.getEndDate())
                .autoRenew(s.getAutoRenew())
                .notes(s.getNotes())
                .createdAt(s.getCreatedAt())
                .updatedAt(s.getUpdatedAt())
                .build();
    }
}
