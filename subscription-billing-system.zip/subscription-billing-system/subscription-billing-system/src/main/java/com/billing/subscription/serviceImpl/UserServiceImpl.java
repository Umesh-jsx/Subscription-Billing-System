package com.billing.subscription.serviceImpl;

import com.billing.subscription.audit.AuditService;
import com.billing.subscription.dto.UserDTO;
import com.billing.subscription.entity.User;
import com.billing.subscription.enums.UserRole;
import com.billing.subscription.exception.DuplicateResourceException;
import com.billing.subscription.exception.ResourceNotFoundException;
import com.billing.subscription.repository.UserRepository;
import com.billing.subscription.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuditService auditService;

    @Override
    public UserDTO.Response createUser(UserDTO.Request request) {
        log.info("Creating user with email: {}", request.getEmail());
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new DuplicateResourceException("Email already registered: " + request.getEmail());
        }
        User user = User.builder()
                .firstName(request.getFirstName())
                .lastName(request.getLastName())
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .phone(request.getPhone())
                .role(request.getRole())
                .active(true)
                .build();
        User saved = userRepository.save(user);
        auditService.log("User", saved.getId(), "CREATE", "SYSTEM", "User created: " + saved.getEmail());
        return toResponse(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public UserDTO.Response getUserById(Long id) {
        return toResponse(findUserById(id));
    }

    @Override
    @Transactional(readOnly = true)
    public UserDTO.Response getUserByEmail(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User", "email", email));
        return toResponse(user);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<UserDTO.Response> getAllUsers(Pageable pageable) {
        return userRepository.findAll(pageable).map(this::toResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<UserDTO.Response> searchUsers(String search, Pageable pageable) {
        return userRepository.searchUsers(search, pageable).map(this::toResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<UserDTO.Response> getUsersByRole(UserRole role, Pageable pageable) {
        return userRepository.findByRole(role, pageable).map(this::toResponse);
    }

    @Override
    public UserDTO.Response updateUser(Long id, UserDTO.UpdateRequest request) {
        log.info("Updating user with id: {}", id);
        User user = findUserById(id);
        user.setFirstName(request.getFirstName());
        user.setLastName(request.getLastName());
        user.setPhone(request.getPhone());
        user.setRole(request.getRole());
        if (request.getActive() != null) {
            user.setActive(request.getActive());
        }
        User updated = userRepository.save(user);
        auditService.log("User", id, "UPDATE", "SYSTEM", "User updated: " + updated.getEmail());
        return toResponse(updated);
    }

    @Override
    public void deleteUser(Long id) {
        log.info("Deleting user with id: {}", id);
        User user = findUserById(id);
        userRepository.delete(user);
        auditService.log("User", id, "DELETE", "SYSTEM", "User deleted: " + user.getEmail());
    }

    @Override
    public void activateUser(Long id) {
        User user = findUserById(id);
        user.setActive(true);
        userRepository.save(user);
        auditService.log("User", id, "ACTIVATE", "SYSTEM", "User activated");
    }

    @Override
    public void deactivateUser(Long id) {
        User user = findUserById(id);
        user.setActive(false);
        userRepository.save(user);
        auditService.log("User", id, "DEACTIVATE", "SYSTEM", "User deactivated");
    }

    private User findUserById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", id));
    }

    private UserDTO.Response toResponse(User user) {
        return UserDTO.Response.builder()
                .id(user.getId())
                .firstName(user.getFirstName())
                .lastName(user.getLastName())
                .email(user.getEmail())
                .phone(user.getPhone())
                .role(user.getRole())
                .active(user.getActive())
                .createdAt(user.getCreatedAt())
                .updatedAt(user.getUpdatedAt())
                .build();
    }
}
