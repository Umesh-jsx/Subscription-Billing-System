package com.billing.subscription.serviceImpl;

import com.billing.subscription.audit.AuditService;
import com.billing.subscription.dto.PlanDTO;
import com.billing.subscription.entity.Plan;
import com.billing.subscription.enums.PlanType;
import com.billing.subscription.exception.DuplicateResourceException;
import com.billing.subscription.exception.ResourceNotFoundException;
import com.billing.subscription.repository.PlanRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PlanServiceImplTest {

    @Mock
    private PlanRepository planRepository;

    @Mock
    private AuditService auditService;

    @InjectMocks
    private PlanServiceImpl planService;

    private PlanDTO.Request planRequest;
    private Plan plan;

    @BeforeEach
    void setUp() {
        planRequest = PlanDTO.Request.builder()
                .name("Basic Plan")
                .description("A basic plan")
                .price(new BigDecimal("9.99"))
                .planType(PlanType.MONTHLY)
                .durationInDays(30)
                .maxUsers(5)
                .active(true)
                .build();

        plan = Plan.builder()
                .id(1L)
                .name("Basic Plan")
                .description("A basic plan")
                .price(new BigDecimal("9.99"))
                .planType(PlanType.MONTHLY)
                .durationInDays(30)
                .maxUsers(5)
                .active(true)
                .build();
    }

    @Test
    void createPlan_Success() {
        when(planRepository.existsByName(anyString())).thenReturn(false);
        when(planRepository.save(any(Plan.class))).thenReturn(plan);

        PlanDTO.Response response = planService.createPlan(planRequest);

        assertNotNull(response);
        assertEquals("Basic Plan", response.getName());
        assertEquals(PlanType.MONTHLY, response.getPlanType());
        verify(planRepository).save(any(Plan.class));
    }

    @Test
    void createPlan_DuplicateName_ThrowsException() {
        when(planRepository.existsByName(anyString())).thenReturn(true);

        assertThrows(DuplicateResourceException.class, () -> planService.createPlan(planRequest));
        verify(planRepository, never()).save(any());
    }

    @Test
    void getPlanById_Success() {
        when(planRepository.findById(1L)).thenReturn(Optional.of(plan));

        PlanDTO.Response response = planService.getPlanById(1L);

        assertNotNull(response);
        assertEquals(1L, response.getId());
    }

    @Test
    void getPlanById_NotFound_ThrowsException() {
        when(planRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> planService.getPlanById(99L));
    }

    @Test
    void deactivatePlan_Success() {
        when(planRepository.findById(1L)).thenReturn(Optional.of(plan));
        when(planRepository.save(any(Plan.class))).thenReturn(plan);

        assertDoesNotThrow(() -> planService.deactivatePlan(1L));
        assertFalse(plan.getActive());
    }
}
